from cmath import sqrt
import math

Val1=float
Val2=float
Val3=float
x=float
x1=float
x2=float

class Equation:
    Val1 = "a" 
    Val2 = "b"
    Val3 = "c"

a = Val1()
b = Val2()
c = Val3()

a = float(input("Entrer la valeur de a:"))
b = float(input("Entrer la valeur de b:"))
c = float(input("Entrer la valeur de c:"))

descr = b**2 - 4*a*c

if descr < 0:

    print("Pas de solution")

elif descr == 0:

    x = -b/(2*a)   
    print("La solution à l'équation est", x)

else:

    x1 =(-b - math.sqrt(descr)) / (2*a)
    x2 =(-b + math.sqrt(descr)) / (2*a)
    print("Les solutions à l'équation sont:", x1, x2)
    
