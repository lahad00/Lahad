import os
import random

if os.path.exists("langue.txt"):
    with open("langue.txt","r+") as file:
        langue_list = file.readlines()
        langue_random_choice = random.choice(langue_list)
        print("Vous pourriez réviser", langue_random_choice)
        file.close()
else:
    print("Le document n'existe pas!")